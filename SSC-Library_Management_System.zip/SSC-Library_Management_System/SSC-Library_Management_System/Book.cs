﻿using System;
using System.Globalization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace SSC_Library_Management_System
{
        [Serializable]
        public class Book : IEquatable<Book>
        {
            private string m_Author;
            private string m_Title;
            private Int64 m_ISBN;
            private int m_Quantity;

            public Book(string author, string title, string isbn, string quant)
            {
                // Class constructor
                if (author == String.Empty)
                    throw new ApplicationException("Author name cannot be empty");
                m_Author = author;
                if (title == String.Empty)
                    throw new ApplicationException("Title name cannot be empty");
                m_Title = title;
                if (!Int64.TryParse(isbn, out m_ISBN))
                    throw new ApplicationException("ISBN must be a valid integer");
                if (!int.TryParse(quant, out m_Quantity))
                    throw new ApplicationException("Quantity is invalid");
            }

            public string Author
            {
                get { return m_Author; }
            }

            public string Title
            {
                get { return m_Title; }
            }

            public Int64 ISBN
            {
                get { return m_ISBN; }
            }

            public int Quanitity
            {
                get { return m_Quantity; }
                set
                {
                    if (value < 0)
                        throw new ApplicationException("Quantity cannot be negative!");
                    m_Quantity = value;
                }
            }

            public override string ToString()
            {
                return Title.PadRight(50 - Title.Length) + "\t" + Author.PadRight(20 - Author.Length) + "\t" + ISBN + "\t" + Quanitity;
            }

            public override int GetHashCode()
            {
                return ISBN.GetHashCode();
            }

            bool IEquatable<Book>.Equals(Book other)
            {
                return this.ISBN == other.ISBN;
            }
        }

}

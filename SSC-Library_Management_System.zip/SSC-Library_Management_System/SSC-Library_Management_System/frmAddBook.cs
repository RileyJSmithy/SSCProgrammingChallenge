﻿using System;
using System.Windows.Forms;

namespace SSC_Library_Management_System
{
    public partial class frmAddBook : Form
    {
        // The object that is returned to the main form
        public Book ViewBook;

        public frmAddBook()
        {
            InitializeComponent();
        }

        private void frmNewBook_Load(object sender, EventArgs e)
        {
            if (ViewBook == null)
                this.Text = "Add new book...";
            else
            {
                this.Text = "Edit book...";
                txtAuthor.Text = ViewBook.Author;
                txtTitle.Text = ViewBook.Title;
                txtISBN.Text = ViewBook.ISBN.ToString();
                txtQuantity.Text = ViewBook.Quanitity.ToString();
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            // create new Book object to hold user's input...
            try
            {
                ViewBook = new Book(txtAuthor.Text, txtTitle.Text, txtISBN.Text, txtQuantity.Text);
            }
            catch (ApplicationException exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // now tell main form that user pressed OK
            this.DialogResult = DialogResult.OK;

            // return to main form by closing this one
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // return to main form by closing this one
            // DialogResult.Cancel is set by default
            this.Close();
        }

    }
}

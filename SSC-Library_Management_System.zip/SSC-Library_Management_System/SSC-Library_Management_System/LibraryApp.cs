﻿using System.Collections;


namespace SSC_Library_Management_System
{
    class LibraryApp
    {
        // Unfortunately, we need to copy data from the form's list box into an ArrayList for
        // reading and writing.  We can't use the generic List<Customer> because the XML formatter
        // can't handle generic types.
        public static void ReadBooks(string inFile, IList formList)
        {
            DataAccess.ReadBooks(inFile, formList);
        }

        public static void WriteBooks(string outFile, IList formList)
        {
            DataAccess.WriteBooks(outFile, formList);
        }
    }
}

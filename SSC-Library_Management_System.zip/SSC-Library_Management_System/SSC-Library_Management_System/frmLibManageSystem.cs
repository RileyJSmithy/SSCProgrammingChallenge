﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SSC_Library_Management_System
{
    public partial class frmLibManageSystem : Form
    {
        public frmLibManageSystem()
        {
            InitializeComponent();
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            frmUser userWindow = new frmUser();
            userWindow.ShowDialog();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {

            if (txtPass.Text == "12345")    //password for Admin access
            {
                frmAdmin adminWindow = new frmAdmin();
                adminWindow.ShowDialog();
            }
            else
                MessageBox.Show("Enter valid password\r Hint: 12345");

        }
    }
}

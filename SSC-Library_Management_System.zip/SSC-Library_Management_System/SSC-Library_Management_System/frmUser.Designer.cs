﻿namespace SSC_Library_Management_System
{
    partial class frmUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstUserBooks = new System.Windows.Forms.ListBox();
            this.lstRentedBooks = new System.Windows.Forms.ListBox();
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // lstUserBooks
            // 
            this.lstUserBooks.FormattingEnabled = true;
            this.lstUserBooks.ItemHeight = 16;
            this.lstUserBooks.Location = new System.Drawing.Point(13, 13);
            this.lstUserBooks.Name = "lstUserBooks";
            this.lstUserBooks.Size = new System.Drawing.Size(595, 244);
            this.lstUserBooks.TabIndex = 1;
            this.lstUserBooks.DoubleClick += new System.EventHandler(this.lstUserBooks_DoubleClick);
            // 
            // lstRentedBooks
            // 
            this.lstRentedBooks.FormattingEnabled = true;
            this.lstRentedBooks.ItemHeight = 16;
            this.lstRentedBooks.Location = new System.Drawing.Point(13, 314);
            this.lstRentedBooks.Name = "lstRentedBooks";
            this.lstRentedBooks.Size = new System.Drawing.Size(595, 116);
            this.lstRentedBooks.TabIndex = 2;
            //this.lstRentedBooks.DoubleClick += new System.EventHandler(this.lstRentedBooks_DoubleClick);
            // 
            // dlgOpenFile
            // 
            this.dlgOpenFile.FileName = "LibraryBooks";
            // 
            // frmUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 442);
            this.Controls.Add(this.lstRentedBooks);
            this.Controls.Add(this.lstUserBooks);
            this.Name = "frmUser";
            this.Text = "User";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstUserBooks;
        private System.Windows.Forms.ListBox lstRentedBooks;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
    }
}
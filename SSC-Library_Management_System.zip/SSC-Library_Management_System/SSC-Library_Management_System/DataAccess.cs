﻿using System.Collections;
using System.IO;
using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace SSC_Library_Management_System
{
    class DataAccess
    {
        // This class is used to read and write an ArrayList containing Book objects.
        // It would probably be good to allow other data structure types to contain the
        // Book objects, but the SoapFormatter can't be used for all types of containers.

        public const string FileFilter = "Text File (*.txt)|*.txt|Binary File (*.bin)|*.bin|XML File (*.xml)|*.xml";

        public static ArrayList ReadBooks(string fileName)
        {
            // Read a text file into an ArrayList.
            ArrayList bookList = new ArrayList();
            StreamReader sr = new StreamReader(fileName);
            string varAuthor, varTitle, varISBN, varQuant; // Hold input fields

            while (sr.Peek() != -1)
            {
                varAuthor = sr.ReadLine();
                varTitle = sr.ReadLine();
                varISBN = sr.ReadLine();
                varQuant = sr.ReadLine();
                bookList.Add(new Book(varAuthor, varTitle, varISBN, varQuant));
            }
            sr.Close();
            return bookList;
        }

        public static void ReadBooks(string fileName, IList bookList)
        {
            // Use the file extension to determine the format of the input.
            string fileExtension = Path.GetExtension(fileName).ToLower();
           if (fileExtension == ".txt")
                ReadText(fileName, bookList);
            else if (fileExtension == ".bin")
                ReadStream(fileName, new BinaryFormatter(), bookList);
            else if (fileExtension == ".xml")
                ReadStream(fileName, new SoapFormatter(), bookList);
            else
                throw new ApplicationException("Invalid file extension: "
                   + fileExtension);
        }


        private static void ReadText(string fileName, IList bookList)
        {
            // Read a text file into an ArrayList.
            ArrayList bkLst = new ArrayList();
            StreamReader sr = new StreamReader(fileName);
            string varAuthor, varTitle, varISBN, varQuant; // Hold input fields

            while (sr.Peek() != -1)
            {
                varAuthor = sr.ReadLine();
                varTitle = sr.ReadLine();
                varISBN = sr.ReadLine();
                varQuant = sr.ReadLine();
                bkLst.Add(new Book(varAuthor, varTitle, varISBN, varQuant));
            }
            sr.Close();
            //       bkLst.Sort();
            foreach (Book c in bkLst)
                bookList.Add(c);
        }

        private static void ReadStream(string fileName, IFormatter formatter, IList bookList)
        {
            // Both binary and XML files can be read with the same code.  The ArrayList collection
            // can be serialized.
            ArrayList bkLst;
            Stream stream = new FileStream(fileName,
                FileMode.Open, FileAccess.Read, FileShare.None);
            bkLst = (ArrayList)formatter.Deserialize(stream);
            stream.Close();
            //           bkLst.Sort();
            foreach (Book c in bkLst)
                bookList.Add(c);
        }




        public static void WriteBooks(string fileName, IList bookList)
        {
            // Use the file extension to determine the desired output format.
            string fileExtension = Path.GetExtension(fileName).ToLower();
            if (fileExtension == ".txt")
                WriteText(fileName, bookList);
            else if (fileExtension == ".bin")
                WriteStream(fileName, bookList, new BinaryFormatter());
            else if (fileExtension == ".xml")
                WriteStream(fileName, bookList, new SoapFormatter());
            else
                throw new ApplicationException("Invalid file extension: "
                   + fileExtension);
        }

        private static void WriteText(string fileName, IList bookList)
        {
            // Write a text file.
            StreamWriter sw = new StreamWriter(fileName);

            foreach (Book c in bookList)
            {
                sw.WriteLine(c.Author);
                sw.WriteLine(c.Title);
                sw.WriteLine(c.ISBN.ToString());
                sw.WriteLine(c.Quanitity.ToString());
            }
            sw.Close();
        }

        private static void WriteStream(string fileName, IList bookList,
            IFormatter formatter)
        {
            // Writing to binary or XML uses the same code.  We need to convert the
            // list to a data structure that can use serialization, such as ArrayList
            ArrayList bkLst = new ArrayList();
            foreach (Book c in bookList)
                bkLst.Add(c);
            Stream stream = new FileStream(fileName, FileMode.Create,
               FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, bkLst);
            stream.Close();
        }

    }
}

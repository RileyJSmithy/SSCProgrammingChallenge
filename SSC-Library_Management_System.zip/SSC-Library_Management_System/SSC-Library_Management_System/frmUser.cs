﻿using System;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Runtime.Serialization;

namespace SSC_Library_Management_System
{
    public partial class frmUser : Form
    {
        public frmUser()
        {
            try
            {
            InitializeComponent();
            dlgOpenFile.Filter = DataAccess.FileFilter;
            string filePath = "LibraryBooks.txt";
                lstUserBooks.Items.Clear();
                if (dlgOpenFile.ShowDialog() == DialogResult.OK)
                {
                    LibraryApp.ReadBooks(filePath, lstUserBooks.Items);
                    if (lstUserBooks.Items.Count > 0)
                    {
                        lstUserBooks.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void lstUserBooks_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("You've requested a book!");
        }
    }
}
